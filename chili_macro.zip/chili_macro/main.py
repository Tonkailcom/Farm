"""
Chili Farm Macro - FiveM / GTA V (Windows 10/11, Python 3.10+)

Flow: G -> Farm -> 40/40 -> L x2 (เปิดหลังรถ) -> double click พริก -> Max -> ESC -> G -> วนซ้ำ
หยุดเมื่อหลังรถเต็ม (400KG)

วิธีรัน:
    python main.py               # ใช้งานจริง
    python main.py --detect      # ทดสอบการตรวจจับอย่างเดียว ไม่กดอะไรเลย
    python main.py --dry-run     # ทดสอบ flow หลังรถ แต่ไม่คลิกจริง
    python main.py --mouse       # แสดงพิกัดเมาส์ (ใช้วัด ITEM_SEARCH_REGION)
"""
from __future__ import annotations

import argparse
import ctypes
import sys
import threading
import time
import traceback
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Callable, Optional

# ทำให้พิกัดเมาส์/ภาพตรงกับพิกเซลจริง แม้ Windows ตั้ง Scale 125%/150%
# (ต้องเรียกก่อน import pyautogui)
try:
    ctypes.windll.shcore.SetProcessDpiAwareness(2)
except Exception:
    try:
        ctypes.windll.user32.SetProcessDPIAware()
    except Exception:
        pass

import cv2
import keyboard
import numpy as np
import pyautogui

import config as cfg

pyautogui.PAUSE = 0
pyautogui.FAILSAFE = cfg.FAILSAFE_CORNER


# ======================================================================
# Logging
# ======================================================================
def log(level: str, msg: str) -> None:
    print(f"[{level}] {msg}", flush=True)


def info(msg: str) -> None:
    log("INFO", msg)


def warn(msg: str) -> None:
    log("WARN", msg)


def error(msg: str) -> None:
    log("ERROR", msg)


# ======================================================================
# State machine
# ======================================================================
class State(Enum):
    IDLE = auto()
    FARMING = auto()
    FULL_DETECTED = auto()
    OPENING_TRUNK = auto()
    FINDING_ITEM = auto()
    TRANSFERRING = auto()
    CLOSING_TRUNK = auto()
    RESTARTING_FARM = auto()
    TRUNK_FULL = auto()
    STOPPED = auto()
    ERROR = auto()


STATUS_TEXT = {
    State.IDLE: ("IDLE", ""),
    State.FARMING: ("FARMING", "Chili: Waiting for 40/40"),
    State.FULL_DETECTED: ("INVENTORY FULL", "Action: 40/40 confirmed"),
    State.OPENING_TRUNK: ("INVENTORY FULL", "Action: Opening Trunk"),
    State.FINDING_ITEM: ("INVENTORY FULL", "Action: Searching Chili"),
    State.TRANSFERRING: ("INVENTORY FULL", "Action: Moving Chili to Trunk"),
    State.CLOSING_TRUNK: ("INVENTORY FULL", "Action: Closing Trunk"),
    State.RESTARTING_FARM: ("RESTARTING", "Action: Pressing G"),
    State.TRUNK_FULL: ("TRUNK FULL", "Action: Finished - trunk is full (400KG)"),
    State.STOPPED: ("STOPPED", ""),
    State.ERROR: ("ERROR", "Macro stopped - check the log above"),
}

# state ที่ปลอดภัยพอจะหยุดเมื่อกด F8
SAFE_STOP_STATES = (State.FARMING, State.RESTARTING_FARM)


class MacroAbort(Exception):
    """ถูกสั่งหยุดฉุกเฉิน (F9 / Failsafe)"""


class MacroError(Exception):
    """ข้อผิดพลาดที่ต้องหยุด Macro"""


# ======================================================================
# Vision (OpenCV template matching)
# ======================================================================
@dataclass
class Match:
    name: str
    score: float
    threshold: float
    left: int          # พิกัดจริงบนหน้าจอ
    top: int
    width: int
    height: int
    origin: tuple = (0, 0)   # มุมซ้ายบนของภาพที่ถ่าย (ใช้วาด debug)
    frame: Optional[np.ndarray] = field(default=None, repr=False)

    @property
    def found(self) -> bool:
        return self.score >= self.threshold

    @property
    def cx(self) -> int:
        return self.left + self.width // 2

    @property
    def cy(self) -> int:
        return self.top + self.height // 2


def _imread(path) -> np.ndarray:
    # np.fromfile รองรับ path ภาษาไทยบน Windows (cv2.imread ไม่รองรับ)
    data = np.fromfile(str(path), dtype=np.uint8)
    img = cv2.imdecode(data, cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError(f"Cannot decode image: {path}")
    return img


class Vision:
    OPTIONAL = {"confirm", "trunk_full"}

    def __init__(self) -> None:
        cfg.DEBUG_DIR.mkdir(exist_ok=True)
        self.templates: dict[str, np.ndarray] = {}
        for name, path in cfg.TEMPLATES.items():
            if not path.exists():
                if name in self.OPTIONAL:
                    info(f"Optional template '{path.name}' not found - skipping")
                    continue
                raise FileNotFoundError(f"Missing template: {path}")
            img = _imread(path)
            if cfg.USE_GRAYSCALE:
                img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            self.templates[name] = img
            h, w = img.shape[:2]
            info(f"Loaded template {path.name} ({w}x{h})")

    def has(self, name: str) -> bool:
        return name in self.templates

    @staticmethod
    def _clip(region):
        if region is None:
            return None
        sw, sh = pyautogui.size()
        left, top, w, h = (int(v) for v in region)
        left, top = max(0, left), max(0, top)
        w, h = min(w, sw - left), min(h, sh - top)
        if w <= 0 or h <= 0:
            return None
        return (left, top, w, h)

    def find(self, name: str, threshold: float, region=None) -> Match:
        """ถ่ายหน้าจอ -> matchTemplate -> คืนค่า Match (found ดูจาก score >= threshold)"""
        tpl = self.templates[name]
        region = self._clip(region)
        shot = pyautogui.screenshot(region=region) if region else pyautogui.screenshot()
        frame = cv2.cvtColor(np.array(shot), cv2.COLOR_RGB2BGR)
        hay = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY) if cfg.USE_GRAYSCALE else frame

        th, tw = tpl.shape[:2]
        if hay.shape[0] < th or hay.shape[1] < tw:
            raise MacroError(f"Template '{name}' is larger than the search area")

        result = cv2.matchTemplate(hay, tpl, cv2.TM_CCOEFF_NORMED)
        _, score, _, loc = cv2.minMaxLoc(result)
        if not np.isfinite(score):
            score = 0.0

        ox, oy = (region[0], region[1]) if region else (0, 0)
        return Match(
            name=name, score=float(score), threshold=threshold,
            left=loc[0] + ox, top=loc[1] + oy, width=tw, height=th,
            origin=(ox, oy), frame=frame,
        )

    @staticmethod
    def save_debug(m: Match, filename: str) -> None:
        if not cfg.DEBUG_MODE or m.frame is None:
            return
        vis = m.frame.copy()
        ox, oy = m.origin
        p1 = (m.left - ox, m.top - oy)
        p2 = (p1[0] + m.width, p1[1] + m.height)
        color = (0, 255, 0) if m.found else (0, 0, 255)
        cv2.rectangle(vis, p1, p2, color, 2)
        label = f"{m.name} score={m.score:.3f} thr={m.threshold:.2f}"
        cv2.putText(vis, label, (max(p1[0], 5), max(p1[1] - 10, 25)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2)
        ok, buf = cv2.imencode(".png", vis, [cv2.IMWRITE_PNG_COMPRESSION, 1])
        if ok:
            buf.tofile(str(cfg.DEBUG_DIR / filename))


# ======================================================================
# Input helpers
# ======================================================================
def release_all_inputs() -> None:
    """ปล่อยทุกปุ่ม/เมาส์ที่อาจค้าง"""
    for k in (cfg.KEY_FARM, cfg.KEY_TRUNK, cfg.KEY_CLOSE):
        try:
            keyboard.release(k)
        except Exception:
            pass
        try:
            pyautogui.keyUp(k)
        except Exception:
            pass
    for b in ("left", "right"):
        try:
            pyautogui.mouseUp(button=b)
        except Exception:
            pass


# ======================================================================
# Window focus helpers (Windows)
# ======================================================================
def _window_title(hwnd) -> str:
    user32 = ctypes.windll.user32
    n = user32.GetWindowTextLengthW(hwnd)
    buf = ctypes.create_unicode_buffer(n + 1)
    user32.GetWindowTextW(hwnd, buf, n + 1)
    return buf.value


def _is_game_title(title: str) -> bool:
    t = title.lower()
    return any(k.lower() in t for k in cfg.GAME_WINDOW_KEYWORDS)


def game_has_focus() -> bool:
    return _is_game_title(_window_title(ctypes.windll.user32.GetForegroundWindow()))


def list_windows() -> list[str]:
    user32 = ctypes.windll.user32
    titles: list[str] = []
    proc_t = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)

    def cb(hwnd, _lp):
        if user32.IsWindowVisible(hwnd):
            t = _window_title(hwnd)
            if t:
                titles.append(t)
        return True

    user32.EnumWindows(proc_t(cb), 0)
    return titles


def focus_game() -> None:
    """พยายามดึงหน้าต่างเกมขึ้นมาด้านหน้า"""
    user32 = ctypes.windll.user32
    found: list[int] = []
    proc_t = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)

    def cb(hwnd, _lp):
        if user32.IsWindowVisible(hwnd) and _is_game_title(_window_title(hwnd)):
            found.append(hwnd)
        return True

    user32.EnumWindows(proc_t(cb), 0)
    if not found:
        return
    hwnd = found[0]
    user32.ShowWindow(hwnd, 9)  # SW_RESTORE
    user32.SetForegroundWindow(hwnd)
    if not game_has_focus():
        # วิธีมาตรฐานเลี่ยงข้อจำกัดของ Windows: แตะ Alt แล้วค่อยสั่ง focus ซ้ำ
        user32.keybd_event(0x12, 0, 0, 0)
        user32.keybd_event(0x12, 0, 2, 0)
        user32.SetForegroundWindow(hwnd)


# ======================================================================
# Macro controller
# ======================================================================
class MacroController:
    def __init__(self, vision: Vision, dry_run: bool = False) -> None:
        self.vision = vision
        self.dry_run = dry_run
        self.state = State.STOPPED
        self._thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()
        self._stop_req = threading.Event()   # F8: หยุดอย่างปลอดภัย
        self._abort = threading.Event()      # F9: หยุดทันที
        self._last_toggle = 0.0
        self._item: Optional[Match] = None
        self._full_hits = 0
        self._farm_started_at = 0.0

    # ---------------- control (เรียกจาก hotkey thread - ต้องเร็ว) ----------------
    def is_running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    def toggle(self) -> None:
        now = time.monotonic()
        if now - self._last_toggle < cfg.HOTKEY_DEBOUNCE:
            return
        self._last_toggle = now
        if self.is_running():
            self.request_stop()
        else:
            self.start()

    def start(self) -> None:
        with self._lock:
            if self.is_running():
                return
            self._stop_req.clear()
            self._abort.clear()
            self._thread = threading.Thread(target=self._run, name="macro", daemon=True)
            self._thread.start()

    def request_stop(self) -> None:
        info("Stop requested - will stop at the next safe point")
        self._stop_req.set()

    def emergency_stop(self) -> None:
        if self.is_running():
            warn("EMERGENCY STOP")
        self._abort.set()
        self._stop_req.set()
        release_all_inputs()

    def shutdown(self, timeout: float = 3.0) -> None:
        self._abort.set()
        self._stop_req.set()
        release_all_inputs()
        if self._thread is not None:
            self._thread.join(timeout)

    # ---------------- low level (อยู่ใน worker thread) ----------------
    def _check_abort(self) -> None:
        if self._abort.is_set():
            raise MacroAbort()

    def _sleep(self, seconds: float) -> None:
        """sleep ที่ถูกขัดจังหวะได้ทันทีเมื่อกด F9 (ไม่ busy loop)"""
        if self._abort.wait(seconds):
            raise MacroAbort()

    def _ensure_focus(self) -> None:
        """ต้องมั่นใจว่าเกมอยู่หน้าสุด ไม่งั้นปุ่ม/คลิกจะไปเข้าโปรแกรมอื่น"""
        if not cfg.GAME_FOCUS_CHECK or game_has_focus():
            return
        warn("Game window is not in front - bringing it to front")
        for _ in range(3):
            focus_game()
            self._sleep(0.35)
            if game_has_focus():
                return
        raise MacroError("Game window not focused. Is FiveM running? "
                         "Check GAME_WINDOW_KEYWORDS (python main.py --list-windows)")

    def _press(self, key: str) -> None:
        self._check_abort()
        self._ensure_focus()
        use_kb = cfg.INPUT_BACKEND == "keyboard"
        try:
            keyboard.press(key) if use_kb else pyautogui.keyDown(key)
            self._sleep(cfg.KEY_HOLD_TIME)
        finally:
            keyboard.release(key) if use_kb else pyautogui.keyUp(key)

    def _move(self, x: int, y: int) -> None:
        self._check_abort()
        self._ensure_focus()
        if not (0 <= x < cfg.SCREEN_WIDTH and 0 <= y < cfg.SCREEN_HEIGHT):
            raise MacroError(f"Target ({x},{y}) is outside the screen - refusing to click")
        pyautogui.moveTo(x, y, duration=cfg.MOUSE_MOVE_DURATION)
        self._sleep(cfg.MOUSE_SETTLE_DELAY)

    def _click(self, button: str = "left") -> None:
        self._check_abort()
        try:
            pyautogui.mouseDown(button=button)
            self._sleep(cfg.CLICK_HOLD_TIME)
        finally:
            pyautogui.mouseUp(button=button)

    def _double_click(self) -> None:
        self._click("left")
        self._sleep(cfg.DOUBLE_CLICK_INTERVAL)
        self._click("left")

    # ---------------- vision helpers ----------------
    def _find_retry(self, name: str, threshold: float, region, tries: int, label: str) -> Match:
        """หาซ้ำได้หลายรอบ คืน Match ล่าสุด (ดู .found)"""
        m = None
        for attempt in range(1, tries + 1):
            self._ensure_focus()
            m = self.vision.find(name, threshold, region)
            if m.found:
                return m
            warn(f"{label} not matched (best score={m.score:.3f} < {m.threshold:.2f}, "
                 f"attempt {attempt}/{tries})")
            if attempt < tries:
                self._sleep(cfg.DIALOG_RETRY_DELAY)
        assert m is not None
        return m

    def _trunk_is_full(self) -> bool:
        """ตรวจ 400.00/400.00 ถ้ามี trunk_full.png"""
        if not self.vision.has("trunk_full"):
            return False
        m = self.vision.find("trunk_full", cfg.TRUNK_FULL_THRESHOLD, cfg.TRUNK_FULL_SEARCH_REGION)
        if m.found:
            info(f"Trunk weight is full (score={m.score:.3f})")
            self.vision.save_debug(m, "trunk_full_detected.png")
            return True
        return False

    # ---------------- state helpers ----------------
    def _set_state(self, new: State) -> None:
        if new == self.state:
            return
        self.state = new
        status, action = STATUS_TEXT[new]
        print(f"Status: {status}" + (f"\n{action}" if action else ""), flush=True)

    # ---------------- state handlers: คืนค่า state ถัดไป (None = จบ) ----------------
    def _h_restart_farm(self) -> State:
        info("Pressing G - Start Farm")
        self._press(cfg.KEY_FARM)
        self._sleep(cfg.START_FARM_DELAY)
        self._full_hits = 0
        self._farm_started_at = time.monotonic()
        info("Farming...")
        return State.FARMING

    def _h_farming(self) -> State:
        self._ensure_focus()
        m = self.vision.find("full", cfg.FULL_THRESHOLD, cfg.FULL_SEARCH_REGION)
        in_grace = (time.monotonic() - self._farm_started_at) < cfg.FARM_RESTART_GRACE
        if m.found and not in_grace:
            self._full_hits += 1
            if self._full_hits >= cfg.FULL_CONFIRM_FRAMES:
                info(f"40/40 detected (score={m.score:.3f})")
                self.vision.save_debug(m, "full_detected.png")
                return State.FULL_DETECTED   # หลังจากนี้ไม่ตรวจ 40/40 ซ้ำจนกว่าจะกลับมา FARMING
        else:
            self._full_hits = 0
        self._sleep(cfg.CHECK_INTERVAL)
        return State.FARMING

    def _h_full_detected(self) -> State:
        return State.OPENING_TRUNK

    def _h_open_trunk(self) -> State:
        n = cfg.TRUNK_KEY_PRESSES
        info(f"Opening trunk (pressing {cfg.KEY_TRUNK.upper()} x{n})")
        for i in range(n):
            self._press(cfg.KEY_TRUNK)
            self._sleep(cfg.TRUNK_KEY_INTERVAL if i < n - 1 else cfg.OPEN_TRUNK_DELAY)
        return State.FINDING_ITEM

    def _h_find_item(self) -> State:
        if self._trunk_is_full():
            return State.TRUNK_FULL
        m = None
        for attempt in range(1, cfg.MAX_ITEM_RETRY + 1):
            self._ensure_focus()
            info(f"Searching for item (attempt {attempt}/{cfg.MAX_ITEM_RETRY})")
            m = self.vision.find("item", cfg.ITEM_THRESHOLD, cfg.ITEM_SEARCH_REGION)
            if m.found:
                info(f"Item found at X={m.cx} Y={m.cy} (score={m.score:.3f})")
                self.vision.save_debug(m, "item_found.png")
                self._item = m
                return State.TRANSFERRING
            warn(f"Item not matched (best score={m.score:.3f} < {m.threshold:.2f})")
            if attempt < cfg.MAX_ITEM_RETRY:
                self._sleep(cfg.ITEM_RETRY_DELAY)
        if m is not None:
            self.vision.save_debug(m, "item_not_found.png")
        if cfg.CLOSE_TRUNK_ON_ERROR:
            self._press(cfg.KEY_CLOSE)
        raise MacroError("Item not found in inventory")

    def _after_transfer_ok(self) -> State:
        return State.TRUNK_FULL if self._trunk_is_full() else State.CLOSING_TRUNK

    def _h_transfer(self) -> Optional[State]:
        match = self._item
        assert match is not None
        for attempt in range(1, cfg.MAX_TRANSFER_ATTEMPTS + 1):
            self._check_abort()
            info(f"Double click item (transfer attempt {attempt}/{cfg.MAX_TRANSFER_ATTEMPTS})")
            self._move(match.cx, match.cy)

            if self.dry_run:
                info(f"[DRY-RUN] Would double click at X={match.cx} Y={match.cy} - NOT clicking")
                info(f"[DRY-RUN] Hovering for {cfg.DRY_RUN_HOVER_SECONDS:.0f}s - check the cursor is on the item")
                self._sleep(cfg.DRY_RUN_HOVER_SECONDS)
                return None

            self._double_click()
            self._sleep(cfg.DOUBLE_CLICK_DELAY)

            mx = self._find_retry("max", cfg.MAX_THRESHOLD, cfg.DIALOG_SEARCH_REGION,
                                  cfg.DIALOG_RETRY, "MAX button")
            if not mx.found:
                cur = self.vision.find("item", cfg.ITEM_THRESHOLD, cfg.ITEM_SEARCH_REGION)
                if not cur.found:
                    info("Item moved without a quantity dialog")
                    return self._after_transfer_ok()
                self.vision.save_debug(mx, "max_not_found.png")
                if cfg.CLOSE_TRUNK_ON_ERROR:
                    self._press(cfg.KEY_CLOSE)
                raise MacroError("MAX button not found after double click")

            info(f"Clicking MAX at X={mx.cx} Y={mx.cy} (score={mx.score:.3f})")
            self.vision.save_debug(mx, "max_found.png")
            self._move(mx.cx, mx.cy)
            self._click("left")
            self._sleep(cfg.MAX_CLICK_DELAY)

            # ปุ่มยืนยัน (ถ้ามี template และปรากฏบนจอเท่านั้นถึงจะคลิก)
            if self.vision.has("confirm"):
                cf = self.vision.find("confirm", cfg.CONFIRM_THRESHOLD, cfg.DIALOG_SEARCH_REGION)
                if cf.found:
                    info(f"Clicking Confirm at X={cf.cx} Y={cf.cy} (score={cf.score:.3f})")
                    self._move(cf.cx, cf.cy)
                    self._click("left")
            self._sleep(cfg.TRANSFER_DELAY)

            # ตรวจซ้ำ: ถ้าพริกยังเหลือในกระเป๋าผู้เล่น = ย้ายไม่หมด (หลังรถอาจเต็ม)
            cur = self.vision.find("item", cfg.ITEM_THRESHOLD, cfg.ITEM_SEARCH_REGION)
            if not cur.found:
                info("All items transferred to the trunk")
                return self._after_transfer_ok()
            info(f"Item still in inventory (score={cur.score:.3f})")
            if self._trunk_is_full():
                return State.TRUNK_FULL
            match = cur

        self.vision.save_debug(match, "transfer_incomplete.png")
        if cfg.STOP_WHEN_ITEM_REMAINS:
            warn(f"Items still remain after {cfg.MAX_TRANSFER_ATTEMPTS} attempts - trunk is probably full (400KG)")
            return State.TRUNK_FULL
        if cfg.CLOSE_TRUNK_ON_ERROR:
            self._press(cfg.KEY_CLOSE)
        raise MacroError(f"Transfer incomplete after {cfg.MAX_TRANSFER_ATTEMPTS} attempts")

    def _h_close_trunk(self) -> State:
        info("Closing trunk")
        self._press(cfg.KEY_CLOSE)
        self._sleep(cfg.CLOSE_TRUNK_DELAY)
        return State.RESTARTING_FARM

    def _h_trunk_full(self) -> Optional[State]:
        if cfg.CLOSE_TRUNK_ON_FINISH:
            info("Closing trunk")
            self._press(cfg.KEY_CLOSE)
            self._sleep(cfg.CLOSE_TRUNK_DELAY)
        info("Trunk is full (400KG) - farming finished, not pressing G")
        return None

    # ---------------- worker ----------------
    def _run(self) -> None:
        info("Macro started")
        handlers: dict[State, Callable[[], Optional[State]]] = {
            State.RESTARTING_FARM: self._h_restart_farm,
            State.FARMING: self._h_farming,
            State.FULL_DETECTED: self._h_full_detected,
            State.OPENING_TRUNK: self._h_open_trunk,
            State.FINDING_ITEM: self._h_find_item,
            State.TRANSFERRING: self._h_transfer,
            State.CLOSING_TRUNK: self._h_close_trunk,
            State.TRUNK_FULL: self._h_trunk_full,
        }
        final = State.STOPPED
        try:
            # dry-run: ข้ามการฟาร์ม ไปเปิดหลังรถทดสอบเลย (รอบเดียว)
            self._set_state(State.FULL_DETECTED if self.dry_run else State.RESTARTING_FARM)
            if self.dry_run:
                info("[DRY-RUN] Skipping farm, testing the trunk flow once")
            while True:
                self._check_abort()
                if self._stop_req.is_set() and self.state in SAFE_STOP_STATES:
                    if self.state == State.FARMING and cfg.STOP_FARM_ON_SAFE_STOP:
                        info("Pressing G - Stop Farm")
                        self._press(cfg.KEY_FARM)
                    break
                nxt = handlers[self.state]()
                if nxt is None:
                    if self.state == State.TRUNK_FULL:
                        final = State.TRUNK_FULL
                    break
                self._set_state(nxt)
        except MacroAbort:
            warn("Macro aborted")
        except pyautogui.FailSafeException:
            warn("PyAutoGUI failsafe triggered (mouse in top-left corner)")
        except MacroError as e:
            error(str(e))
            final = State.ERROR
        except Exception as e:  # noqa: BLE001
            error(f"Unexpected error: {e}")
            traceback.print_exc()
            final = State.ERROR
        finally:
            release_all_inputs()
            self._set_state(final)
            if final == State.ERROR:
                error("Macro stopped")
            else:
                info("Macro stopped")


# ======================================================================
# Console UI / modes
# ======================================================================
def print_banner(dry_run: bool) -> None:
    line = "=" * 40
    print(line)
    print("CHILI FARM MACRO" + ("  [DRY-RUN]" if dry_run else ""))
    print(line)
    print(f"{cfg.HOTKEY_START_STOP.upper():<4}= Start / Stop")
    print(f"{cfg.HOTKEY_EMERGENCY.upper():<4}= Emergency Stop")
    print(f"{cfg.HOTKEY_QUIT.upper():<4}= Exit program")
    print()
    print("Status: STOPPED")
    print(line, flush=True)


def check_screen() -> None:
    w, h = pyautogui.size()
    if (w, h) != (cfg.SCREEN_WIDTH, cfg.SCREEN_HEIGHT):
        warn(f"Screen is {w}x{h} but config expects {cfg.SCREEN_WIDTH}x{cfg.SCREEN_HEIGHT}. "
             "Templates may not match - recapture them or update config.py")
    else:
        info(f"Screen {w}x{h} OK")


def run_detect(vision: Vision) -> None:
    """โหมดทดสอบ: ถ่ายหน้าจอ + แสดงคะแนน ไม่กดปุ่ม/เมาส์ใด ๆ"""
    info("DETECT mode - no input is sent. Press Ctrl+C to quit.")
    checks = [
        ("FULL", "full", cfg.FULL_THRESHOLD, cfg.FULL_SEARCH_REGION),
        ("ITEM", "item", cfg.ITEM_THRESHOLD, cfg.ITEM_SEARCH_REGION),
        ("MAX", "max", cfg.MAX_THRESHOLD, cfg.DIALOG_SEARCH_REGION),
        ("CONFIRM", "confirm", cfg.CONFIRM_THRESHOLD, cfg.DIALOG_SEARCH_REGION),
        ("TRUNK_FULL", "trunk_full", cfg.TRUNK_FULL_THRESHOLD, cfg.TRUNK_FULL_SEARCH_REGION),
    ]
    try:
        while True:
            parts = []
            for label, name, thr, region in checks:
                if not vision.has(name):
                    continue
                m = vision.find(name, thr, region)
                vision.save_debug(m, f"detect_{name}.png")
                parts.append(f"{label} {m.score:.3f} "
                             + (f"FOUND X={m.cx} Y={m.cy}" if m.found else "-"))
            print(" | ".join(parts), flush=True)
            time.sleep(1.0)
    except KeyboardInterrupt:
        info("Detect mode ended")


def run_mouse() -> None:
    """แสดงพิกัดเมาส์ตลอดเวลา ใช้วัดค่า ITEM_SEARCH_REGION"""
    info("MOUSE mode - move the mouse to the corners of the area. Press Ctrl+C to quit.")
    try:
        while True:
            x, y = pyautogui.position()
            print(f"\rX={x:<5} Y={y:<5}", end="", flush=True)
            time.sleep(0.15)
    except KeyboardInterrupt:
        print()
        info("Mouse mode ended")


def main() -> int:
    parser = argparse.ArgumentParser(description="Chili Farm Macro (FiveM)")
    parser.add_argument("--detect", action="store_true", help="only test detection, no input")
    parser.add_argument("--dry-run", action="store_true",
                        help="test trunk flow once; hover the item but never click")
    parser.add_argument("--mouse", action="store_true", help="print mouse coordinates")
    parser.add_argument("--list-windows", action="store_true",
                        help="list visible window titles (to set GAME_WINDOW_KEYWORDS)")
    args = parser.parse_args()

    if args.list_windows:
        for t in list_windows():
            print(t)
        return 0
    if args.mouse:
        run_mouse()
        return 0

    try:
        vision = Vision()
    except (FileNotFoundError, ValueError) as e:
        error(str(e))
        error("Put your template images in the templates/ folder (see README.md)")
        return 1

    check_screen()

    if args.detect:
        run_detect(vision)
        return 0

    if cfg.ITEM_SEARCH_REGION is None:
        if cfg.REQUIRE_ITEM_REGION and not args.dry_run:
            error("ITEM_SEARCH_REGION is not set in config.py")
            error("The trunk also contains chili icons - without a region the macro could "
                  "double click the wrong side and move items back. See README.md")
            return 1
        warn("ITEM_SEARCH_REGION is not set - the macro may pick an item from the trunk side")

    controller = MacroController(vision, dry_run=args.dry_run)
    quit_event = threading.Event()

    keyboard.add_hotkey(cfg.HOTKEY_START_STOP, controller.toggle, suppress=cfg.HOTKEY_SUPPRESS)
    keyboard.add_hotkey(cfg.HOTKEY_EMERGENCY, controller.emergency_stop, suppress=cfg.HOTKEY_SUPPRESS)
    keyboard.add_hotkey(cfg.HOTKEY_QUIT, quit_event.set)

    print_banner(args.dry_run)
    try:
        while not quit_event.is_set():
            quit_event.wait(0.25)   # รอแบบไม่กิน CPU
    except KeyboardInterrupt:
        pass
    finally:
        controller.shutdown()
        keyboard.unhook_all()
        info("Bye")
    return 0


if __name__ == "__main__":
    sys.exit(main())
