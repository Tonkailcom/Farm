
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
TEMPLATE_DIR = BASE_DIR / "templates"
DEBUG_DIR = BASE_DIR / "debug"

# ------------------------------------------------------------------
# หน้าจอ
# ------------------------------------------------------------------
SCREEN_WIDTH = 1920
SCREEN_HEIGHT = 1080

# ------------------------------------------------------------------
# Hotkeys (F8 ใน FiveM = Console จึงตั้ง SUPPRESS ไว้เพื่อไม่ให้ส่งเข้าเกม)
# ------------------------------------------------------------------
HOTKEY_START_STOP = "f8"
HOTKEY_EMERGENCY = "f9"
HOTKEY_QUIT = "f10"
HOTKEY_SUPPRESS = True
HOTKEY_DEBOUNCE = 0.4

# ปุ่มในเกม
KEY_FARM = "g"
KEY_TRUNK = "l"              # เปิดหลังรถ
TRUNK_KEY_PRESSES = 2        # กด L กี่ครั้งเพื่อเปิดหลังรถ
KEY_CLOSE = "esc"            # ปิดหน้าหลังรถ

INPUT_BACKEND = "keyboard"   # "keyboard" (scan code) | "pyautogui"
KEY_HOLD_TIME = 0.06
CLICK_HOLD_TIME = 0.06
DOUBLE_CLICK_INTERVAL = 0.09 # เวลาระหว่างคลิก 2 ครั้งของ double click

# ------------------------------------------------------------------
# Template Matching
# ------------------------------------------------------------------
TEMPLATES = {
    "full": TEMPLATE_DIR / "full_40.png",           # บังคับ: 40/40 บน HUD
    "item": TEMPLATE_DIR / "chili.png",             # บังคับ: ไอคอนพริกใน Inventory ผู้เล่น
    "max": TEMPLATE_DIR / "max.png",                # บังคับ: ปุ่ม Max
    "confirm": TEMPLATE_DIR / "confirm.png",        # ไม่บังคับ: ปุ่มยืนยันหลังกด Max
    "trunk_full": TEMPLATE_DIR / "trunk_full.png",  # ไม่บังคับ: 400.00/400.00
}

FULL_THRESHOLD = 0.85
ITEM_THRESHOLD = 0.85
MAX_THRESHOLD = 0.85
CONFIRM_THRESHOLD = 0.85
TRUNK_FULL_THRESHOLD = 0.90

USE_GRAYSCALE = True
FULL_CONFIRM_FRAMES = 100      # ต้องเจอ 40/40 ติดกันกี่รอบ

# จำกัดบริเวณค้นหา (left, top, width, height) None = ทั้งจอ
FULL_SEARCH_REGION = None    # เช่น HUD ล่างกลางจอ (900, 1200, 800, 240)
DIALOG_SEARCH_REGION = None  # หน้าถามจำนวน (Max / ยืนยัน)
TRUNK_FULL_SEARCH_REGION = None

# !!! สำคัญมาก !!!
# บริเวณของ Inventory ฝั่ง "ผู้เล่น" เท่านั้น (ไม่รวมฝั่งหลังรถ)
# เพราะในหลังรถก็มีไอคอนพริกเหมือนกัน ถ้าไม่จำกัด Macro อาจดับเบิลคลิกพริกฝั่งหลังรถ
# แล้วย้ายกลับเข้ากระเป๋า วัดค่าด้วย: python main.py --mouse
# ตัวอย่าง: ITEM_SEARCH_REGION = (300, 300, 900, 800)
ITEM_SEARCH_REGION = (140,262, 855,794)
REQUIRE_ITEM_REGION = True   # True = ไม่ยอมรันจริงถ้ายังไม่ตั้ง ITEM_SEARCH_REGION

# ------------------------------------------------------------------
# Timing (วินาที)
# ------------------------------------------------------------------
CHECK_INTERVAL = 0.15
START_FARM_DELAY = 1.0
TRUNK_KEY_INTERVAL = 0.5     # เวลารอระหว่างการกด L แต่ละครั้ง
OPEN_TRUNK_DELAY = 3.5       # รอให้หน้าหลังรถเปิดเต็มที่
ITEM_RETRY_DELAY = 0.6
DOUBLE_CLICK_DELAY = 1.0     # รอหน้าถามจำนวนขึ้นหลัง double click
MAX_CLICK_DELAY = 0.4
TRANSFER_DELAY = 0.9         # รอให้ย้ายของเสร็จ
CLOSE_TRUNK_DELAY = 0.8
DIALOG_RETRY_DELAY = 0.4
MOUSE_MOVE_DURATION = 0.12
MOUSE_SETTLE_DELAY = 0.10

# ------------------------------------------------------------------
# Retry / Failsafe
# ------------------------------------------------------------------
MAX_ITEM_RETRY = 5           # หาไอคอนพริกไม่เจอ ลองซ้ำกี่รอบ
MAX_TRANSFER_ATTEMPTS = 3    # ย้ายของสูงสุดกี่รอบต่อ 1 ครั้งที่เต็ม
DIALOG_RETRY = 5             # หาปุ่ม Max ไม่เจอ ลองซ้ำกี่รอบ

# หลังพยายามย้ายครบรอบแล้วพริกยังเหลือในกระเป๋า = หลังรถเต็ม (400KG) -> หยุด Macro
STOP_WHEN_ITEM_REMAINS = True
CLOSE_TRUNK_ON_FINISH = True    # หยุดเพราะหลังรถเต็ม แล้วกด ESC ปิดหน้าหลังรถให้
CLOSE_TRUNK_ON_ERROR = False

FAILSAFE_CORNER = True       # ลากเมาส์ไปมุมซ้ายบน = หยุดฉุกเฉิน
STOP_FARM_ON_SAFE_STOP = True  # กด F8 หยุดตอนกำลังฟาร์ม -> กด G ปิด Auto Farm ให้

# ------------------------------------------------------------------
# หน้าต่างเกมต้องอยู่หน้าสุดตอนกดปุ่ม/คลิก
# ------------------------------------------------------------------
GAME_FOCUS_CHECK = True
GAME_WINDOW_KEYWORDS = ("FiveM", "Grand Theft Auto" ,"FiveM® by Cfx.re - ซัมเมอร์ซิตี้ ซีซั่นสอง")  # ดูชื่อจริง: python main.py --list-windows
FARM_RESTART_GRACE = 3.0     # หลังกด G ข้ามการตรวจ 40/40 กี่วินาที (กัน HUD ค้างเลขเก่า)

# ------------------------------------------------------------------
# Debug
# ------------------------------------------------------------------
DEBUG_MODE = True
DRY_RUN_HOVER_SECONDS = 4.0
